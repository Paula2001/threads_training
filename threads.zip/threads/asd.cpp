#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
#include <fcntl.h>           /* For O_* constants */
#include <sys/stat.h>        /* For mode constants */
#include <semaphore.h>

#define SEMAPHORE_NAME "/my_semaphore"
#define NUM_CHILDREN 5

int main() {
    sem_t *semaphore;
    pid_t pid;
    int i;

    // Unlink the semaphore first to ensure it's fresh
    sem_unlink(SEMAPHORE_NAME);

    // Create a named semaphore
    semaphore = sem_open(SEMAPHORE_NAME, O_CREAT, 0644, 1);
    if (semaphore == SEM_FAILED) {
        perror("sem_open failed");
        exit(EXIT_FAILURE);
    }

    for (i = 0; i < NUM_CHILDREN; i++) {
        pid = fork();
        if (pid < 0) {
            perror("fork failed");
            exit(EXIT_FAILURE);
        }

        // Child process
        if (pid == 0) {
            sem_wait(semaphore); // Acquire the semaphore

            // Critical section
            printf("Child process %d is in the critical section.\n", i);
            sleep(1); // Simulate some work

            sem_post(semaphore); // Release the semaphore
            exit(0); // Child process exits
        }
    }

    // Parent process waits for all child processes to finish
    for (i = 0; i < NUM_CHILDREN; i++) {
        wait(NULL);
    }

    // Close and unlink the semaphore
    sem_close(semaphore);
    sem_unlink(SEMAPHORE_NAME);

    return 0;
}
