#include <iostream>
#include <sys/socket.h>
#include <netinet/in.h>
#include <unistd.h>
#include <string.h>
#include <mutex>
#include <queue>
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <semaphore.h>

using namespace std;

#define PORT 9000
#define N 100
#define BUFFER_SIZE 1024
#define ACK "ACK"

sem_t empt, full;
pthread_mutex_t mutx;
std::queue<string> q;

struct SocketData {
    int socket;
};

void *producer(void *param) {
    SocketData *data = static_cast<SocketData*>(param);
    int socketProducer = data->socket;
    delete data;

    while (true) {
        char buffer[BUFFER_SIZE] = {0};
        int read_bytes = read(socketProducer, buffer, BUFFER_SIZE);

        if (read_bytes <= 0) {
            cout << "Producer disconnected or error occurred." << endl;
            break; // Exiting the loop and ending the thread
        }

        sem_wait(&empt);
        pthread_mutex_lock(&mutx);

        cout << "Producer: " << buffer << endl;
        q.emplace(buffer);
        send(socketProducer, ACK, strlen(ACK), 0);

        pthread_mutex_unlock(&mutx);
        sem_post(&full);
    }

    close(socketProducer);
    return NULL;
}

void *consumer(void *param) {
    SocketData *data = static_cast<SocketData*>(param);
    int socketConsumer = data->socket;
    delete data;
    char ackBuf[3] = {0};
    while (true) {
        sem_wait(&full);
        pthread_mutex_lock(&mutx);

        if (q.empty()) {
            pthread_mutex_unlock(&mutx);
            continue; // INFO: Go back to the start of the loop if queue is somehow empty
        }

        string message = q.front();
        q.pop();

        pthread_mutex_unlock(&mutx);
        sem_post(&empt);

        int sent_bytes = send(socketConsumer, message.c_str(), message.length(), 0);
        if (sent_bytes <= 0) {
            cout << "Consumer disconnected or error occurred." << endl;
            break; // Exiting the loop and ending the thread
        }
        read(socketConsumer, ackBuf, 3);
    }

    close(socketConsumer);
    return NULL;
}

void setConsumerOrProducer(int socket, const string& type) {
    pthread_t thread;
    SocketData *data = new SocketData{socket};

    if (type == "PRODUCER") {
        pthread_create(&thread, NULL, producer, data);
    } else if (type == "CONSUMER") {
        pthread_create(&thread, NULL, consumer, data);
    }
    pthread_detach(thread); // Detach the thread
}

int main() {
    sem_init(&empt, 0, N);
    sem_init(&full, 0, 0);
    pthread_mutex_init(&mutx, NULL);

    int server_fd;
    struct sockaddr_in address;
    int addrlen = sizeof(address);

    server_fd = socket(AF_INET, SOCK_STREAM, 0);
    if (server_fd == 0) {
        perror("socket failed");
        exit(EXIT_FAILURE);
    }

    address.sin_family = AF_INET;
    address.sin_addr.s_addr = INADDR_ANY;
    address.sin_port = htons(PORT);

    if (bind(server_fd, (struct sockaddr *)&address, sizeof(address)) < 0) {
        perror("bind failed");
        exit(EXIT_FAILURE);
    }

    if (listen(server_fd, 10) < 0) {
        perror("listen");
        exit(EXIT_FAILURE);
    }

    while (true) {
        cout << "waiting for connection" <<endl;
        int new_socket;
        if ((new_socket = accept(server_fd, (struct sockaddr *)&address, (socklen_t*)&addrlen)) < 0) {
            perror("accept");
            continue;
        }

        char buffer[10];
        int read_bytes = read(new_socket, buffer, 10);
        if (read_bytes <= 0) {
            close(new_socket);
            continue; // Ignore this connection if an error occurred
        }

        string type(buffer);
        setConsumerOrProducer(new_socket, type);
    }

    return 0;
}
